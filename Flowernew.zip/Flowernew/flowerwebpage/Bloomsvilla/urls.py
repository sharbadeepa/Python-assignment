from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.firstview, name='firstview'),
    path('second', views.secondview, name='secondview'),

]
