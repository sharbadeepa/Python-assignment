from django.db import models

# Create your models here.
class Flowers(models.Model):
    flower_name = models.CharField(max_length=300)
    price = models.IntegerField()
    no_of_plants = models.IntegerField()



