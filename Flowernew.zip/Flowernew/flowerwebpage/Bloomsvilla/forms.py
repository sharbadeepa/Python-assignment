from .models import Flowers
from django import forms
from django.db import models





class FlowerForm(forms.ModelForm):
    class Meta:
        model = Flowers
        fields = (
            'flower_name',
            'price',
            'no_of_plants'
        
        )
    
    



