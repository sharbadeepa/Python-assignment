from django.shortcuts import render
from django.http import HttpResponse
from .models import Flowers
from .forms import FlowerForm




# Create your views here.


def firstview(request):
    #ORMS
        
    q1 = Flowers.objects.all()
    print(q1)
    q2 = Flowers.objects.get(id=1)
    q2.price=5000
    q2.save()
    print(q2.price)
    q3 = Flowers.objects.filter(flower_name__startswith='c')
    print(q3)
    q4 = Flowers.objects.create(flower_name='daliya', price=2500, no_of_plants=3)
    q4.save()
    q5 = Flowers.objects.get(id__exact=3)
    print(q5.flower_name)
    q6=Flowers.objects.filter(pk__in=[1,3])
    print(q6)

    #forms
    # if request.method == 'POST':
    #     flower_name = request.Post.get('flower_name')
    #     price = request.Post.get('price')
    #     no_of_plants = request.Post.get('no_of_plants')

    #     flower = 


 
    return render(request, 'base.html')

def secondview(request):
    form = FlowerForm(request.POST or None)
    if form.is_valid():
        form.save()
    context = {
        'form': form
    }
    return render(request, 'base.html', context)


    

