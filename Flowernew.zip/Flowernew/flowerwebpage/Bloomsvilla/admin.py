from django.contrib import admin
from . models import Flowers


# Register your models here.

admin.site.register(Flowers)
